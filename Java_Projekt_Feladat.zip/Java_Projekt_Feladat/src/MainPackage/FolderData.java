/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainPackage;


import java.io.File;
import java.util.List;

/**
 *
 * @author TUF Gaming
 */
public class FolderData {
    private final String konyvtarHelye;
    private final List<File> kepek;
    private final List<File> alkonyvtarak;

    public FolderData(String konyvtarHelye, List<File> kepek, List<File> alkonyvtarak) {
        this.konyvtarHelye = konyvtarHelye;
        this.kepek = kepek;
        this.alkonyvtarak = alkonyvtarak;
    }

    public String getKonyvtarHelye() {
        return konyvtarHelye;
    }

    public List<File> getKepek() {
        return kepek;
    }

    public List<File> getAlkonyvtarak() {
        return alkonyvtarak;
    }


}
