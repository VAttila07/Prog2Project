/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainPackage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

/**
 *
 * @author TUF Gaming
 */
public class HtmlGenerator {
    
    private final File rootDir;
      
    public HtmlGenerator(File rootDir) {
        this.rootDir = rootDir;
    }

    // Main orchestration method
    public void generate(Map<String, FolderData> folderStructure) throws IOException {          
        
        // Iterate through EVERY folder found (Root and Subfolders)
        for (FolderData data : folderStructure.values()) {
            
            // 1. Generate an index.html for THIS specific folder
            generateFolderIndex(data);
            
            // 2. Generate HTML pages for images in THIS specific folder
            generateImagePages(data);
        }
    }
    
    /**
     * Generates an index.html for a specific folder (Root or Subfolder).
     */
    private void generateFolderIndex(FolderData data) throws IOException {
        
        // Determine where to save the index.html
        File targetDir = new File(rootDir, data.getKonyvtarHelye());
        File indexFile = new File(targetDir, "index.html");

        try (PrintWriter writer = new PrintWriter(new FileWriter(indexFile))) {
            writer.println("<!DOCTYPE html>");
            writer.println("<html lang=\"hu\">");
            writer.println("<head>");
            writer.println("<meta charset=\"UTF-8\">");
            // If relative path is empty, it's Root, otherwise use folder name
            String titleName = data.getKonyvtarHelye().isEmpty() ? rootDir.getName() : new File(data.getKonyvtarHelye()).getName();
            writer.println("<title>Galéria: " + titleName + "</title>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("<h1>Galéria: " + titleName + "</h1>");

            // --- Navigation: Back to Root (Only if we are in a subfolder) ---
            if (!data.getKonyvtarHelye().isEmpty()) {
                writer.println("<p><a href=\"../index.html\">⬆ Vissza a Főoldalra</a></p>");
                writer.println("<hr>");
            }

            // --- Subfolder Links (Only if there are subdirectories) ---
            if (!data.getAlkonyvtarak().isEmpty()) {
                writer.println("<h2>Alkönyvtárak</h2>");
                writer.println("<ul>");
                for (File subDir : data.getAlkonyvtarak()) {
                    // Link to the index.html INSIDE the subfolder
                    // Example: "Japan/index.html"
                    writer.println("<li><a href=\"" + subDir.getName() + "/index.html\">📂 " + subDir.getName() + "</a></li>");
                }
                writer.println("</ul>");
                writer.println("<hr>");
            }

            // --- Image Links (Images in the CURRENT folder) ---
            if (!data.getKepek().isEmpty()) {
                writer.println("<h2>Képek</h2>");
                writer.println("<div style=\"display:flex; flex-wrap:wrap;\">");
                for (File imageFile : data.getKepek()) {
                    
                    String htmlPath = getHtmlFileName(imageFile);
                    
                    writer.println("<div style=\"margin: 10px; text-align:center;\">");
                    writer.println("<a href=\"" + htmlPath + "\">");
                    // Thumbnail
                    writer.println("<img src=\"" + imageFile.getName() + "\" alt=\"" + imageFile.getName() + "\" style=\"width: 150px; height: 150px; object-fit: cover; border: 1px solid #ccc;\">");
                    writer.println("</a>");
                    writer.println("<br><span>" + imageFile.getName() + "</span>");
                    writer.println("</div>");
                }
                writer.println("</div>");
            } else if (data.getAlkonyvtarak().isEmpty()) {
                writer.println("<p>Ez a mappa üres.</p>");
            }

            writer.println("</body>");
            writer.println("</html>");
        }
    }
    
    private String getHtmlFileName(File imageFile) {
        return imageFile.getName() + ".html"; 
    }
    
    private void generateImagePages(FolderData data) throws IOException {
        List<File> images = data.getKepek();

        // The relative path string is used to find the target folder
        File targetDir = new File(rootDir, data.getKonyvtarHelye());

        for (int i = 0; i < images.size(); i++) {
            File currentImage = images.get(i);
            File prevImage = (i > 0) ? images.get(i - 1) : null;
            File nextImage = (i < images.size() - 1) ? images.get(i + 1) : null;

            File htmlFile = new File(targetDir, getHtmlFileName(currentImage));

            try (PrintWriter writer = new PrintWriter(new FileWriter(htmlFile))) {
                writer.println("<!DOCTYPE html>");
                writer.println("<html lang=\"hu\">");
                writer.println("<head>");
                writer.println("<meta charset=\"UTF-8\">");
                writer.println("<title>" + currentImage.getName() + "</title>");
                writer.println("</head>");
                writer.println("<body>");

                writer.println("<h1>" + currentImage.getName() + "</h1>");

                // --- Back Link ---
                writer.println("<p><a href=\"index.html\">⬆ Vissza a mappához</a></p>");

                // --- Navigation (Prev/Next Text Links) ---
                writer.println("<div style=\"display:flex; justify-content: space-between; margin-bottom: 20px;\">");

                // Previous Link
                if (prevImage != null) {
                    String prevHtml = getHtmlFileName(prevImage);
                    writer.println("<a href=\"" + prevHtml + "\">← Előző</a>");
                } else {
                    writer.println("<span></span>"); 
                }

                // Next Link
                if (nextImage != null) {
                    String nextHtml = getHtmlFileName(nextImage);
                    writer.println("<a href=\"" + nextHtml + "\">Következő →</a>");
                } else {
                    writer.println("<span></span>"); 
                }
                writer.println("</div>");

                // --- Image Display (Clickable to Next) ---
                writer.println("<div style=\"text-align:center;\">");
                
                if (nextImage != null) {
                    String nextHtml = getHtmlFileName(nextImage);
                    // Wrap the image in an anchor tag pointing to the next image
                    writer.println("<a href=\"" + nextHtml + "\" title=\"Kattints a következő képhez\">");
                    writer.println("<img src=\"" + currentImage.getName() + "\" alt=\"" + currentImage.getName() + "\" style=\"max-width: 100%; max-height: 80vh; height: auto; cursor: pointer;\">");
                    writer.println("</a>");
                } else {
                    // If it is the last image, just display it (it won't be clickable)
                    writer.println("<img src=\"" + currentImage.getName() + "\" alt=\"" + currentImage.getName() + "\" style=\"max-width: 100%; max-height: 80vh; height: auto;\">");
                }
                
                writer.println("</div>");

                writer.println("</body>");
                writer.println("</html>");
            }
        }
    }
}