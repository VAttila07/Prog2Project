/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainPackage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

/**
 *
 * @author TUF Gaming
 */
public class HtmlGenerator {
    
    private final File rootDir;
      
    public HtmlGenerator(File rootDir) {
        this.rootDir = rootDir;
    }

    
    public void generate(Map<String, FolderData> folderStructure) throws IOException {          
        
        
        for (FolderData data : folderStructure.values()) {
            
            //Mappa index.html generálása
            generateFolderIndex(data);
            
            //Kepek htmljének generálása
            generateImagePages(data);
        }
    }
    

    private void generateFolderIndex(FolderData data) throws IOException {
        
        //Megnézzük hová kell az index.html-t rakni.
        File targetDir = new File(rootDir, data.getKonyvtarHelye());
        //Index.html-t generálása a célmappába.
        File indexFile = new File(targetDir, "index.html");

        try (PrintWriter writer = new PrintWriter(new FileWriter(indexFile))) {
            writer.println("<!DOCTYPE html>");
            writer.println("<html lang=\"hu\">");
            writer.println("<head>");
            writer.println("<meta charset=\"UTF-8\">");
            //Ha a relatív elérési út üres, akkor root, ha nem akkor az almappa nevét használja.
            String titleName = data.getKonyvtarHelye().isEmpty() ? rootDir.getName() : new File(data.getKonyvtarHelye()).getName();
            
            writer.println("<title>Galéria: " + titleName + "</title>");
            writer.println("</head>");
            writer.println("<body>");
            writer.println("<h1>Galéria: " + titleName + "</h1>");

            //Ha alkönyvtárban vagyunk, akkor vissza a főoldalra gomb.
            if (!data.getKonyvtarHelye().isEmpty()) {
                writer.println("<p><a href=\"../index.html\">⬆ Vissza a Főoldalra</a></p>");
                writer.println("<hr>");
            }

            //Ha van alkönyvtár, generáljunk nekik linket
            if (!data.getAlkonyvtarak().isEmpty()) {
                writer.println("<h2>Alkönyvtárak</h2>");
                writer.println("<ul>");
                for (File subDir : data.getAlkonyvtarak()) {
                    writer.println("<li><a href=\"" + subDir.getName() + "/index.html\">📂  " + subDir.getName() + "</a></li>");
                }
                writer.println("</ul>");
                writer.println("<hr>");
            }

            //A JELENLEGI könyvtár képeinek generálása:
            if (!data.getKepek().isEmpty()) {
                writer.println("<h2>Képek</h2>");
                writer.println("<div style=\"display:flex; flex-wrap:wrap;\">");
                for (File imageFile : data.getKepek()) {
                    
                    String htmlPath = getHtmlFileName(imageFile);
                    
                    writer.println("<div style=\"margin: 10px; text-align:center;\">");
                    writer.println("<a href=\"" + htmlPath + "\">");
                    //Kép legenerálása kicsiben (előnézet).
                    writer.println("<img src=\"" + imageFile.getName() + "\" alt=\"" + imageFile.getName() + "\" style=\"width: 150px; height: 150px; object-fit: cover; border: 1px solid #ccc;\">");
                    writer.println("</a>");
                    writer.println("<br><span>" + imageFile.getName() + "</span>");
                    writer.println("</div>");
                }
                writer.println("</div>");
            } else if (data.getAlkonyvtarak().isEmpty()) {
                writer.println("<p>Ez a mappa üres.</p>");
            }

            writer.println("</body>");
            writer.println("</html>");
        }
    }
    
    private String getHtmlFileName(File imageFile) {
        return imageFile.getName() + ".html"; 
    }
    
    private void generateImagePages(FolderData data) throws IOException {
        List<File> images = data.getKepek();

        //Célkönyvtár kiválasztása
        File targetDir = new File(rootDir, data.getKonyvtarHelye());
        //Összes kép kiválasztása
        for (int i = 0; i < images.size(); i++) {
            File currentImage = images.get(i);
            File prevImage = (i > 0) ? images.get(i - 1) : null; //Ha azt akarom, hogy ne legyen vége és végtelen lapozás legyen, akkor null helyett images.get(images.size()-1)
            File nextImage = (i < images.size() - 1) ? images.get(i + 1) : null; //Ha azt akarom, hogy ne legyen vége és végtelen lapozás legyen, akkor null helyett 0
                                                                    //Viszont akkor lentebb is kéne a kódon változtatni.
            File htmlFile = new File(targetDir, getHtmlFileName(currentImage));

            try (PrintWriter writer = new PrintWriter(new FileWriter(htmlFile))) {
                writer.println("<!DOCTYPE html>");
                writer.println("<html lang=\"hu\">");
                writer.println("<head>");
                writer.println("<meta charset=\"UTF-8\">");
                writer.println("<title>" + currentImage.getName() + "</title>");
                writer.println("</head>");
                writer.println("<body>");

                writer.println("<h1>" + currentImage.getName() + "</h1>");

                //Vissza link
                writer.println("<p><a href=\"index.html\">⬆ Vissza a mappához</a></p>");

                //A képek lapozásához a linkeknek div
                writer.println("<div style=\"display:flex; justify-content: space-between; margin-bottom: 20px;\">");

                //Előző kép
                if (prevImage != null) {
                    String prevHtml = getHtmlFileName(prevImage);
                    writer.println("<a href=\"" + prevHtml + "\">← Előző</a>");
                } else {
                    writer.println("<span></span>"); 
                }

                //Kövi kép
                if (nextImage != null) {
                    String nextHtml = getHtmlFileName(nextImage);
                    writer.println("<a href=\"" + nextHtml + "\">Következő →</a>");
                } else {
                    writer.println("<span></span>"); 
                }
                writer.println("</div>");

                //A képek középre igazítása, illetve gombá alakítása
                writer.println("<div style=\"text-align:center;\">");
                
                if (nextImage != null) {
                    String nextHtml = getHtmlFileName(nextImage);
                    //A képet egy <a href> be csomagolom, így egy gomb lesz.
                    writer.println("<a href=\"" + nextHtml + "\" title=\"Kattints a következő képhez\">");
                    writer.println("<img src=\"" + currentImage.getName() + "\" alt=\"" + currentImage.getName() + "\" style=\"max-width: 100%; max-height: 80vh; height: auto; cursor: pointer;\">");
                    writer.println("</a>");
                } else {
                    //Ha az utolsó kép, ne legyen gomb.
                    writer.println("<img src=\"" + currentImage.getName() + "\" alt=\"" + currentImage.getName() + "\" style=\"max-width: 100%; max-height: 80vh; height: auto;\">");
                }
                
                writer.println("</div>");

                writer.println("</body>");
                writer.println("</html>");
            }
        }
    }
}