/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainPackage;

import java.io.File;
import java.io.IOException;
import static java.lang.System.exit;
import java.util.Map;

/**
 *
 * @author TUF Gaming
 */
public class Main {
    public static void main(String[] args) {
        if (args.length==0) {
            System.out.println("Error: nincs könyvtár megadva. Segítséghez használd a -h vagy help argumentumot");
            exit(0);
        }
        if (args[0].equals("-h") || args[0].equals("help") ) {
            System.out.println("/path/to/directory <args>");
            System.out.println("Arguments: -delete: törli a könyvtárban már meglévő html állományokat.");
        }
        else if(args.length == 1 && !(args[0].equals("-delete"))){
            File rootDir = new File(args[0]);

            // Validate the root directory path
            if (!rootDir.isDirectory()) {
                System.err.println("Error: A megadott elérési út (" + args[0] + ") nem létező vagy nem könyvtár.");
                exit(1);
            }   
            System.out.println("Indítás: HTML galéria generálása a(z) " + rootDir.getAbsolutePath() + " könyvtárban...");

            try {
                // A. Scan the directory
                SearchDirectory scanner = new SearchDirectory();
                Map<String, FolderData> structure = scanner.scanDirectory(rootDir);

                System.out.println("Szkennelés befejezve. " + structure.size() + " mappát találtunk.");

                // B. Generate the HTML files
                HtmlGenerator generator = new HtmlGenerator(rootDir);
                generator.generate(structure);

                System.out.println("Sikeres befejezés: Az összes HTML fájl generálva lett a képek mellett.");

                } catch (IOException e) {
                System.err.println("Hiba történt a fájlok olvasása vagy írása közben: " + e.getMessage());
                exit(1);
            }
        }
        else if (args.length > 1 && args[1].equals("-delete")) {
            File rootDir = new File(args[0]);
            if (!rootDir.isDirectory()) {
                System.err.println("Error: A megadott elérési út (" + args[0] + ") nem létező vagy nem könyvtár.");
                exit(1);
            }   
            System.out.println("Indítás: Meglévő HTML állományok törlése a(z) " + rootDir.getAbsolutePath() + " könyvtárból...");
            
            // Note: You would need to implement a FileCleaner or add a delete method
            // to HtmlGenerator to handle this logic cleanly. For simplicity, we'll
            // sketch the direct file operations here.
            
            deleteHtmlFiles(rootDir);
            
            System.out.println("Sikeres befejezés: Minden .html fájl törölve lett.");
        } 
        
        // 4. Unknown arguments
        else {
             System.err.println("Hiba: Ismeretlen argumentum(ok). Segítséghez használd a -h vagy help argumentumot.");
             exit(1);
        }
    }
    
    private static void deleteHtmlFiles(File currentDir) {
        
        File[] entries = currentDir.listFiles();
        if (entries == null) {
            return;
        }

        for (File entry : entries) {
            
            // Check for HTML files in the current directory and delete them
            if (entry.isFile() && entry.getName().toLowerCase().endsWith(".html")) {
                if (entry.delete()) {
                    // System.out.println("Törölve: " + entry.getName());
                } else {
                    System.err.println("Hiba: Nem sikerült törölni: " + entry.getAbsolutePath());
                }
            } 
            // Check for subdirectories and recurse (only one level deep)
            else if (entry.isDirectory()) {
                // We assume this is only called on the rootDir, so we recurse once
                deleteHtmlFiles(entry);
            }
        }
    }
}

