/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainPackage;

import java.io.File;
import java.io.IOException;
import static java.lang.System.exit;
import java.util.Map;

/**
 *
 * @author TUF Gaming
 */
public class Main {
    public static void main(String[] args) {
        if (args.length==0) {
            System.out.println("Error: nincs könyvtár megadva. Segítséghez használd a -h vagy help argumentumot");
            exit(0);
        }
        if (args[0].equals("-h") || args[0].equals("help") ) {
            System.out.println("/path/to/directory <args>");
            System.out.println("Arguments: -delete: törli a könyvtárban már meglévő html állományokat.");
        }
        else if(args.length == 1 && !(args[0].equals("-delete"))){
            File rootDir = new File(args[0]);

            // A megadott könyvtár ellenőrzése
            if (!rootDir.isDirectory()) {
                System.err.println("Error: A megadott elérési út (" + args[0] + ") nem létezik vagy nem egy könyvtár.");
                exit(1);
            }   
            
            

            try {
                //Könyvtár átnézése
                SearchDirectory scanner = new SearchDirectory();
                Map<String, FolderData> structure = scanner.scanDirectory(rootDir);

                

                //HTML Fájlok generálása
                HtmlGenerator generator = new HtmlGenerator(rootDir);
                generator.generate(structure);

                

                } catch (IOException e) {
                System.err.println("Hiba történt a fájlok olvasása vagy írása közben: " + e.getMessage());
                exit(1);
            }
        }
        else if (args.length > 1 && args[1].equals("-delete")) {
            File rootDir = new File(args[0]);
            if (!rootDir.isDirectory()) {
                System.err.println("Error: A megadott elérési út (" + args[0] + ") nem létezik vagy nem egy könyvtár.");
                exit(1);
            }   
            
            //HTML fájlok törlése.
            deleteHtmlFiles(rootDir);

        } 
        
        //Ismeretlen argumentumok
        else {
             System.err.println("Hiba: Ismeretlen argumentum(ok). Segítséghez használd a -h vagy help argumentumot.");
             exit(1);
        }
    }
    
    private static void deleteHtmlFiles(File currentDir) {
        
        File[] entries = currentDir.listFiles();
        if (entries == null) {
            return;
        }

        for (File entry : entries) {
            
            //Ellenőrzi, hogy HTML-re végződik-e a file.
            if (entry.isFile() && entry.getName().toLowerCase().endsWith(".html")) {
                entry.delete();
            } 
            //Ha vannak alkönyvtárak azokat is tisztítjuk
            else if (entry.isDirectory()) {                
                deleteHtmlFiles(entry);
            }
        }
    }
}

