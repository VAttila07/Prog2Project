/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MainPackage;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author TUF Gaming
 */
public class SearchDirectory {
    private static final List<String> kiterjesztesek = new ArrayList(List.of(".jpg",".png",".jpeg"));
    
    private final Map<String, FolderData> konyvtarStruktura = new HashMap<>();
    
    private File rootEleresiUt;
    
    public Map<String, FolderData> scanDirectory(File path){
        this.rootEleresiUt = path;
        rekurzivScan(this.rootEleresiUt, 0);
        return konyvtarStruktura;
    }

    private void rekurzivScan(File eleresiUt, int szint) {
        
        if (szint > 1) {
            return; 
        }
        
        File[] bemenetek = eleresiUt.listFiles();

        List<File> kepek = new ArrayList<>();
        List<File> alkonyvtarak = new ArrayList<>();
        
        //Ellenörizzük, hogy a fájlt sikeresen megnyitottam-e.
        if (bemenetek == null) {
            System.err.println("Error reading directory: " + eleresiUt.getAbsolutePath());
            return;
        }
        
        for(File be : bemenetek){
            if (be.isDirectory()) {
                //Ha a főkönyvtár alkönyvtára, csak akkor nézzük át és adjuk a html-hez
                if (szint == 0) { 
                    alkonyvtarak.add(be);
                }
            }
            else if(be.isFile()){
                if(isImage(be.getName())){
                    kepek.add(be);
                }
            }

        }
        
        if (!kepek.isEmpty() || !alkonyvtarak.isEmpty()) {
             //Relatív elérési út.
             String relativePath = rootEleresiUt.toURI().relativize(eleresiUt.toURI()).getPath(); //Ha a főkönyvtárban vagyunk, akkor üres lesz a relatív elérési út (rootPath-rootPath="").
             FolderData data = new FolderData(relativePath, kepek, alkonyvtarak);
             konyvtarStruktura.put(relativePath, data);
        }
        
        if (szint == 0) {
                for (File subDir : alkonyvtarak) {
                    rekurzivScan(subDir, szint + 1);
                }
        }
    }
    //Kép-e a file vagy más
    private boolean isImage(String fileName){
        String kicsibe = fileName.toLowerCase();
        int pontIndex = kicsibe.lastIndexOf(".");
        if (pontIndex > 0) {
            String kiterjesztes = kicsibe.substring(pontIndex);
            return kiterjesztesek.contains(kiterjesztes);
        }
        return false;
    }

}
